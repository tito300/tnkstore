const products = [{
  id: '12395930095',
  title: 'Christmas t-shirt',
  discreption: 'This is a special t-shirt for Christmas season',
  photo: 'imgs/Christmas t-shirt.jpg',
  price: 24.99,
}, {
  id: '123959300903059',
  title: 'Funny coding t-shirt',
  discreption: 'If you love coding, this is for you',
  photo: 'imgs/Funny coding t-shirt.jpg',
  price: 19.99,
}, {
  id: '1239234425930095',
  title: 'Hunting t-shirt',
  discreption: 'A special t-shirt for Hunting season',
  photo: 'imgs/Hunting t-shirt.jpg',
  price: 29.99,
}, {
  id: '123959334320095',
  title: 'Hunting funny t-shirt',
  discreption: 'A funny t-shirt for Hunting season',
  photo: 'imgs/Hunting funny t-shirt.jpg',
  price: 14.99,
}, {
  id: '121233395930095',
  title: 'Hunting t-shirt',
  discreption: 'A special t-shirt for Hunting season',
  photo: 'imgs/Hunting t-shirt.jpg',
  price: 29.99,
}, {
  id: '123959300433395',
  title: 'Hunting funny t-shirt',
  discreption: 'A funny t-shirt for Hunting season',
  photo: 'imgs/Hunting funny t-shirt.jpg',
  price: 14.99,
},
{
  id: '123959300433395',
  title: 'Party t-shirt',
  discreption: 'A funny t-shirt for Hunting season',
  photo: 'imgs/party-tshirt.jpg',
  secondaryPhotos: ['/imgs/party-tshirt-var-women.jpg',
                    '/imgs/party-tshirt-info.jpg',
                    '/imgs/party-tshirt.jpg'],
  price: 14.99,
  variants: {
    male: [{color: "red", sizes: ['l', 's', 'xl']},
           {color: "black", sizes: ['l', 'xl']}],
    female: [{color: "red", sizes: [ 's', 'xl']},
             {color: "red", sizes: ['l', 's']}]
  }
}]


module.exports = products
