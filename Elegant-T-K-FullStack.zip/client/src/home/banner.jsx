import React from 'react';

export default () => {
    return (
        <div className="part1">
            <div className="text-animate">
                <p>T</p>
                <p>n</p>
                <p id="k">K</p>
                <p>Q</p>
                <p>u</p>
                <p>a</p>
                <p>l</p>
                <p>i</p>
                <p>t</p>
                <p>y</p>
            </div>

            <p className="meta">Where You Can Buy Quality.</p>
        </div>
    )
}