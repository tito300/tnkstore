import React from 'react';

export default () => {
    return (
        <>
            <img className="arrow next" src="/imgs/Arrow-2.png" alt="" style={{ display: 'block' }}></img>
            <span className="scroll" style={{ display: 'block' }}>SCROLL</span>
        </>
    )
}